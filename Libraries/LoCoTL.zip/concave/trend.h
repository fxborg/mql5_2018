#pragma once
#define _USE_MATH_DEFINES
#include <vector> 
#include <numeric>
#include <algorithm>
#include <iostream>
#include <math.h>


struct TrendPoint {
	int flg = -1;
	double x = 0.0;
	double y = 0.0;
	double alpha = 0.0;
	double beta = 0.0;
	double residual=0.0;

	TrendPoint() = default;
	
	TrendPoint(double x, double y) :
		x(x),
		y(y)
	{}
	
	TrendPoint(double x, double y, double a, double b) :
		x(x),
		y(y),
		alpha(a),
		beta(b)
	{}

};

class CTrend
{

public:

	explicit CTrend(const int dir);
	void push(const double x, const double y);
	bool get_trend(double &x, double &a, double &b,double &r)const;
	void clear();
	size_t size() const;
private:
	void calculate();
	void calculate2();
	void convex(const int dir);
	static int closs(const TrendPoint & o, const TrendPoint & a, const TrendPoint & b);
	static int direction(const int dir) ;
	int m_dir;


	double m_last_x;
	std::vector<std::pair<double,double>> m_series;
	std::vector<TrendPoint>m_hull;
};