﻿#define EXPORT  extern "C" // __declspec(dllexport)  
#define _USE_MATH_DEFINES

#define DEBUG

#include <deque> 
#include <vector> 
#include <numeric>
#include <algorithm>
#include <iterator>
#include <math.h>
#include <chrono>

#include "series.h"


struct CConst
{
	static const int DIR_LEFT;
	static const int DIR_RIGHT;
	static const int DIR_NONE;
	static const int DIR_HIGH;
	static const int DIR_LOW;
	static const int CONCAVE_BRIDGE;
	static const int CONCAVE_SHIFT;
	static const int CONCAVE_SKIP;
	static const int CONCAVE_ERROR;
	static const int ZZ_OFF;
	static const int ZZ_ON;
	static const int BUFFER_TYPE_CONCAVE;
	static const int BUFFER_TYPE_ZIGZAG;

};


struct Point
{
	double x = 0.0;
	double y = 0.0;
	size_t id = 0;

	Point() = default;

	Point(const size_t id, const double x, const double y) :
		 id(id),
		 x(x),
		 y(y)
	{}
};

using PointDeque = std::deque<Point>;



class CConcave
{
public:
	// コンストラクタ
	explicit CConcave(const double scale_x, const double arm_size);
	int push(const int x, const double h, const double l, const time_t t0, const time_t t1);
	bool calculate();
	size_t get_size(const int typ, const int dir);
	bool get_buffer( const int typ, const int dir,const size_t idx, size_t & x, double & y);


private:
	size_t minmax(const size_t n, const size_t min, const size_t max);
	double minmax(const double n, const double min, const double max);
	static void concave_hull(PointDeque &hull, Point &last_point, const std::deque<Price>::const_iterator &it, const double arm_size, const int dir);

	static int concave(const Point & a, const Point & b, const Point & c, const double arm_size, const int dir);

//	static Point get_circle_points(const Point  &a, const Point &b, const double  r, const int dir);
	static int get_side(const Point &a, const Point &b, const Point &p);
	static double distance(const Point &a, const Point &b);

	static size_t find_peak(const PointDeque & points);
	static size_t find_valley(const PointDeque & points);
	static bool peak(const Point & a, const Point & b, const Point & c);
	static bool valley(const Point & a, const Point & b, const Point & c);

	static bool Equal(double a, double b);
	static bool Zero(double a);
	static bool LessThan(double a, double b);
	static bool LessThanOrEqual(double a, double b);
	static bool GreaterThan(double a, double b);
	static bool GreaterThanOrEqual(double a, double b);


	const double m_arm_size;
	const double m_scale_x;
	const double m_scale_factor;
	const size_t m_size;
	size_t m_prev_calculated;
	Point m_last_h;
	Point m_last_l;

	int m_state_h;
	int m_state_l;

	CSeries m_series_h;
	CSeries m_series_l;

	PointDeque m_upper;
	PointDeque m_lower;

	PointDeque m_zz_h;
	PointDeque m_zz_l;


};

//--- インスタンスを生成
EXPORT CConcave * __stdcall Create(const double scale_x, const double r);
//--- インスタンスを破棄
EXPORT void __stdcall Destroy(CConcave* instance);
//--- インスタンス経由でpushメソッドをコール
EXPORT int __stdcall Push(CConcave* instance, const int x, const double h, const double l, const time_t t0, const time_t t1);
//--- concave hullを計算
EXPORT bool __stdcall Calculate(CConcave* instance);

//--- 結果を取得
EXPORT size_t __stdcall GetSize(CConcave* instance, const int typ,const int dir);
EXPORT bool __stdcall GetBuffer(CConcave* instance, const int typ, const int dir, const size_t idx, size_t &x, double &y);

