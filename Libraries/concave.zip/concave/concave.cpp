﻿#include "concave.h"

const int CConst::DIR_LEFT = 1;
const int CConst::DIR_RIGHT = -1;
const int CConst::DIR_NONE = 0;
const int CConst::DIR_HIGH = 1;
const int CConst::DIR_LOW = -1;

const int CConst::CONCAVE_BRIDGE = 0; // |A-B-C  -->  |A-C-?
const int CConst::CONCAVE_SHIFT  = 1; // |A-B-C  --> A|B-C-? 
const int CConst::CONCAVE_SKIP   = 2; // |A-B-C  -->  |A-B-?
const int CConst::CONCAVE_ERROR  = -1;



const size_t CConst::SIZE_T_MAX = -1;
const size_t CConst::MAX_BUFFER_SIZE = 2000;
EXPORT CConcave * __stdcall Create(const double scale_x, const double arm_size, const float slope, const float angle)
{
	return new CConcave(scale_x, arm_size, slope, angle);
}

EXPORT void __stdcall Destroy(CConcave * instance)
{
	delete instance;
}

EXPORT int __stdcall Push(CConcave * instance, const size_t x, const double h, const double l, const time_t t0, const time_t t1)
{
	return instance->push(x, h, l, t0, t1);
}

EXPORT bool __stdcall Calculate(CConcave* instance)
{
	return instance->calculate();
}


//--- 結果を取得
EXPORT int __stdcall GetSize(CConcave* instance,  const int dir)
{
	return instance->get_size(dir);

}
EXPORT bool __stdcall GetBuffer(CConcave* instance,  const int dir, const size_t idx, size_t &x, double &y, float &slope, int & vertex)
{
	return instance->get_buffer( dir, idx, x, y, slope, vertex);
}

CConcave::CConcave(const double scale_x, const double arm_size,const float slope, const float angle) :
	m_arm_size(minmax(arm_size, 0.0, 100000.0)),
	m_scale_x(minmax(scale_x, 0.000001, 100000)),
	m_scale_factor(1.0 / m_scale_x),
	m_slope((float)minmax(slope, 0.0, 180.0)),
	m_slope_rad(m_slope*PI / 180.0f),
	m_angle((float)minmax(angle, 0.0, 180.0)),
	m_angle_rad(m_angle*PI / 180.0f),
	m_size(std::max(1,int(m_arm_size*m_scale_factor))*3),
	m_prev_calculated(0),
	m_last_h(0, 0.0, 0.0,0.0F),
	m_last_l(0, 0.0, 0.0,0.0F),
	m_state_h(0),
	m_state_l(0),
	m_series(m_size)


{

}


int CConcave::push(const size_t x, const double h, const double l, const time_t t0, const time_t t1)
{
	int result = 0;
	try
	{
		result = m_series.push(x, h, l, t0, t1);
		concave_hull();

	}
	catch (...)
	{
		result = -9999;
	}

	return result;
}
void CConcave::concave_hull()
{

	if (!m_series.is_adding()) return;
	size_t prev_calculated = m_prev_calculated;

	const std::deque<Price> & series_h = m_series.get_h_series();
	const std::deque<Price> & series_l = m_series.get_l_series();
	size_t h_sz = series_h.size();

	if (h_sz < 3)return;
	size_t calc_begin = 0;

	if (m_prev_calculated > 0)
	{
		calc_begin = h_sz - 2;
		while (calc_begin > 0 && series_h[calc_begin - 1].x > m_prev_calculated)
		{
			calc_begin--;
		}

	}
	
	for (size_t i = calc_begin; i < h_sz - 1; ++i)
	{

		m_prev_calculated = series_h[i].x;
		// upper
		if (m_upper.size() > 0 && m_last_h.id == 0)
		{
			m_last_h = { series_h[i].x, m_scale_x * (double)series_h[i].x, series_h[i].y ,0.0F};
			m_last_h.slope = angle(m_upper.back(), m_last_h);
		}
		else if (m_upper.size() == 0)
		{
			m_upper.emplace_back(series_h[i].x, m_scale_x * (double)series_h[i].x, series_h[i].y,0.0);
			m_last_h = { 0,0.0,0.0,0.0F };
		}
		else
		{
			concave_hull(m_upper, m_last_h, series_h, i, m_arm_size, CConst::DIR_LEFT);
			if (m_upper.size() > CConst::MAX_BUFFER_SIZE)m_upper.pop_front();
		}
		// lower
		if (m_lower.size() > 0 && m_last_l.id == 0)
		{
			m_last_l = { series_l[i].x, m_scale_x * (double)series_l[i].x, series_l[i].y ,0.0F };
			m_last_l.slope = angle(m_lower.back(), m_last_l);
		}
		else if (m_lower.size() == 0)
		{
			m_lower.emplace_back(series_l[i].x, m_scale_x * (double)series_l[i].x, series_l[i].y, 0.0);
			m_last_l = { 0,0.0,0.0,0.0F };
		}
		else
		{
			concave_hull(m_lower, m_last_l, series_l, i, m_arm_size, CConst::DIR_RIGHT);
			if (m_lower.size() > CConst::MAX_BUFFER_SIZE)m_lower.pop_front();
		}
	}
}

bool CConcave::calculate()
{
	return true;
}


void CConcave::concave_hull(PointDeque & hull, Point & last_point, const std::deque<Price> & series, const size_t idx, const double arm_size, const int dir)
{
	size_t i = idx;
	while (true)
	{
		Point new_point{ series[i].x, m_scale_x * (double)series[i].x, series[i].y,0.0F };

		int result = concave(hull.back(), last_point, new_point, arm_size, dir);

		if (result == CConst::CONCAVE_BRIDGE)
		{
			last_point = new_point;
			last_point.slope = angle(hull.back(), last_point);
		}
		else if (result == CConst::CONCAVE_SHIFT)
		{
			hull.emplace_back(last_point.id, last_point.x, last_point.y,last_point.slope);
			Point prev_point{ hull.back() };
			while (i > 0 && series[i-1].x > prev_point.id) i--;
			last_point={ series[i].x, m_scale_x * (double)series[i].x, series[i].y, 0.0F };
			last_point.slope = angle(hull.back(), last_point);

		}

		if (idx <= i) break;
		i++; 
	}

}

int CConcave::concave(const Point & a, const Point & b, const Point & c, const double arm_size, const int dir)
{
	if ((a.id == b.id && a.x == b.x) || (b.id == c.id && b.x == c.x))
	{
		return CConst::CONCAVE_SKIP;
	}
	if (GreaterThan(c.x - a.x, arm_size))			return CConst::CONCAVE_SHIFT; // Bを正式採用 Cを候補に

	const bool inside{ get_side(a,c,b) == dir * -1 };
	if (inside)	return CConst::CONCAVE_BRIDGE;	// Bを却下しCを候補に
	else return CConst::CONCAVE_SKIP;	// Cを却下
}

int CConcave::get_size(const int dir)
{
	if (dir == CConst::DIR_HIGH)
	{
		return (int)m_upper.size()+1;
	}
	else if (dir == CConst::DIR_LOW)
	{
		return (int)m_lower.size()+1;
	}
	
	
	return 0;
}
bool CConcave::get_buffer(const int dir, const size_t idx, size_t & x, double & y, float & slope , int & vertex)
{
	if (dir == CConst::DIR_HIGH)
	{
		const size_t sz{ m_upper.size() };
		if (sz < idx)
		{
			return false;
		}

		float next_slope = 0;

		if (sz == idx)
		{
			x = m_last_h.id;
			y = m_last_h.y;
			slope = m_last_h.slope;		
		}
		else
		{
			x = m_upper[idx].id;
			y = m_upper[idx].y;
			slope = m_upper[idx].slope;
			if (sz - 1 == idx)
			{
				next_slope = m_last_h.slope;
			}
			else
			{
				next_slope= m_upper[idx + 1].slope;
			}
		}
		if (slope > -m_slope_rad && next_slope < m_slope_rad && slope - next_slope > m_angle_rad)	vertex = 1;
		else if (slope < m_slope_rad && next_slope > -m_slope_rad && slope - next_slope < -m_angle_rad) vertex = -1;
		else vertex = 0;

		return true;

	}
	else if (dir == CConst::DIR_LOW)
	{

		const size_t sz{ m_lower.size() };
		if (sz < idx)
		{
			return false;
		}

		float next_slope = 0;

		if (sz == idx)
		{
			x = m_last_l.id;
			y = m_last_l.y;
			slope = m_last_l.slope;
		}
		else
		{
			x = m_lower[idx].id;
			y = m_lower[idx].y;
			slope = m_lower[idx].slope;
			if (sz - 1 == idx)
			{
				next_slope = m_last_l.slope;
			}
			else
			{
				next_slope = m_lower[idx + 1].slope;
			}
		}
		if (slope > -m_slope_rad && next_slope < m_slope_rad && slope - next_slope > m_angle_rad)	vertex = 1;
		else if (slope < m_slope_rad && next_slope > -m_slope_rad && slope - next_slope < -m_angle_rad) vertex = -1;
		else vertex = 0;

		return true;
	}
	return false;

}

bool CConcave::peak(const Point & a, const Point & b, const float threshold) 
{
	return  a.slope - b.slope >  threshold;
}
bool CConcave::valley(const Point & a, const Point & b, const float threshold)
{
	return  a.slope - b.slope < -threshold;
}
size_t CConcave::find_peak(const PointDeque & points, const float threshold)
{
	if (points.size() < 3)return 0;
	size_t res = 0;
	for (size_t i = points.size()-1; i >0 ; --i)
	{
		if (peak(points[i - 1],points[i ], threshold))
		{
			res = i - 1;
			break;
		}
	}
	return res;
}
size_t CConcave::find_valley(const PointDeque & points, const float threshold)
{
	if (points.size() < 3)return 0;
	size_t res = 0;
	for (size_t i = points.size() - 1; i >0; --i)
	{
		if (valley(points[i - 1], points[i], threshold))
		{
			res = i - 1;
			break;
		}
	}
	return res;
}


int CConcave::get_side(const Point &a, const Point &b, const Point &p)
{
	const double n = p.x * (a.y - b.y) + a.x * (b.y - p.y) + b.x * (p.y - a.y);

	if (n > 0)		return  CConst::DIR_LEFT; 
	else if (n < 0) return  CConst::DIR_RIGHT; 
	else            return  CConst::DIR_NONE; 
}

double CConcave::distance(const Point &a , const Point & b) {
	return sqrt((b.x - a.x) * (b.x - a.x) + (b.y - a.y) * (b.y - a.y));
}

float CConcave::angle(const Point &a, const Point & b) {
	return tbl_atan2( (float)(b.y - a.y), (float)(b.x - a.x));
}


size_t CConcave::minmax(const size_t n, const size_t min, const size_t max)
{
	return std::max(min, std::min(max, n));
}

double CConcave::minmax(const double n, const double min, const double max)
{
	return std::max(min, std::min(max, n));
}




bool CConcave::Equal(double a, double b)				{ return fabs(a - b) <= DBL_EPSILON; }
bool CConcave::Zero(double a)							{ return fabs(a) <= DBL_EPSILON; }
bool CConcave::LessThan(double a, double b)				{ return a < (b - DBL_EPSILON); }
bool CConcave::LessThanOrEqual(double a, double b)		{ return a <= (b + DBL_EPSILON); }
bool CConcave::GreaterThan(double a, double b)			{ return a >(b + DBL_EPSILON); }
bool CConcave::GreaterThanOrEqual(double a, double b)	{ return a >= (b + DBL_EPSILON); }

