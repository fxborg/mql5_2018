
#include <Windows.h>
#include <tchar.h>
#include <iostream>

#include <fstream>
#include <string>
#include <vector>


typedef int(__stdcall *Fn_ExpClass_Create)( double, double);
typedef bool(__stdcall *Fn_ExpClass_Calc)(int);
typedef void(__stdcall *Fn_ExpClass_Destroy)(int);

typedef int(__stdcall *Fn_ExpClass_PushTrend)(int, const double x, const double y, const int dir);
typedef bool(__stdcall *Fn_ExpClass_GetTrend)(int, double &x, double &a, double &b,double &r, const int dir);


int main()
{
	HMODULE hDll = ::LoadLibrary(_T("concave.dll"));
	if (hDll == 0)
	{
		int errorCode = GetLastError();
		std::cout << errorCode;
		return 1;
	}
	Fn_ExpClass_Create ExpClass_Create = (Fn_ExpClass_Create)GetProcAddress(hDll, "Create");
	Fn_ExpClass_Destroy ExpClass_Destroy = (Fn_ExpClass_Destroy)GetProcAddress(hDll, "Destroy");
	Fn_ExpClass_PushTrend ExpClass_PushTrend = (Fn_ExpClass_PushTrend)GetProcAddress(hDll, "PushTrend");
	Fn_ExpClass_GetTrend ExpClass_GetTrend = (Fn_ExpClass_GetTrend)GetProcAddress(hDll, "GetTrend");

	int ptr = ExpClass_Create(0.1,1.0);
	time_t t0 = 1000;
	time_t t1 = 1000;
	t1 = t0;

	std::string src_path = "C:\\Temp\\data\\USDJPYHL.dat";
	std::ifstream fin(src_path);
	if (fin.bad()) {
		std::cout << "File Open Error:" << src_path << std::endl;
		return 1;
	}
	std::cout << "File Open!:" << src_path << std::endl;
	std::string str;
	int n = 0;
	double high,low;
	std::vector<std::vector<double>>sample;
	while (std::getline(fin, str))
	{
		int res = sscanf_s(str.c_str(), "%lf\t%lf", &high, &low);

		if (res != 2)continue;
		n++;
		t1 = t0++;

		std::cout << n << "," << high << std::endl;
		ExpClass_PushTrend(ptr, n, high, 1);

		ExpClass_PushTrend(ptr, n, low, -1);
	
		if (n > 15)break;
	
	}
	double a, b,x,r;
	if (ExpClass_GetTrend(ptr,x, a, b,r, 1))
	{
		std::cout << "UP " <<a << "," << b << std::endl;
	}
	if (ExpClass_GetTrend(ptr,x, a, b,r, -1))
	{
		std::cout << "DN " << a << "," << b << std::endl;
	}


	fin.close();

	ExpClass_Destroy(ptr);

	
	system("pause");
	return 0;
}
