﻿#include "concave.h"

const int CConst::DIR_LEFT = 1;
const int CConst::DIR_RIGHT = -1;
const int CConst::DIR_NONE = 0;
const int CConst::DIR_HIGH = 1;
const int CConst::DIR_LOW = -1;

const int CConst::CONCAVE_BRIDGE = 0; // |A-B-C  -->  |A-C-?
const int CConst::CONCAVE_SHIFT  = 1; // |A-B-C  --> A|B-C-? 
const int CConst::CONCAVE_SKIP   = 2; // |A-B-C  -->  |A-B-?
const int CConst::CONCAVE_ERROR  = -1;

const int CConst::ZZ_OFF = 0;
const int CConst::ZZ_ON = 1;

const int CConst::BUFFER_TYPE_CONCAVE = 1;
const int CConst::BUFFER_TYPE_ZIGZAG = 2;



EXPORT CConcave * __stdcall Create(const double scale_x, const double arm_size)
{
	return new CConcave(scale_x, arm_size);
}

EXPORT void __stdcall Destroy(CConcave * instance)
{
	delete instance;
}

EXPORT int __stdcall Push(CConcave * instance, const int x, const double h, const double l, const time_t t0, const time_t t1)
{
	return instance->push(x, h, l, t0, t1);
}

EXPORT bool __stdcall Calculate(CConcave* instance)
{
	return instance->calculate();
}


//--- 結果を取得
EXPORT size_t __stdcall GetSize(CConcave* instance, const int typ, const int dir)
{
	return instance->get_size(typ, dir);

}
EXPORT bool __stdcall GetBuffer(CConcave* instance, const int typ, const int dir, const size_t idx, size_t &x, double &y)
{
	return instance->get_buffer(typ, dir, idx, x, y);
}

size_t CConcave::get_size(const int typ, const int dir)
{
	if (typ == CConst::BUFFER_TYPE_CONCAVE )
	{
		if (dir == CConst::DIR_HIGH) 
		{
			return m_upper.size();
		}
		else if (dir == CConst::DIR_LOW)
		{
			return m_lower.size();
		}
	}
	else if (typ == CConst::BUFFER_TYPE_ZIGZAG )
	{
		if (dir == CConst::DIR_HIGH)
		{
			return m_zz_h.size();
		}
		else if (dir == CConst::DIR_LOW)
		{
			return m_zz_l.size();
		}
	}
	return 0;
}
bool CConcave::get_buffer(const int typ, const int dir, const size_t idx, size_t & x, double & y)
{
	if (typ == CConst::BUFFER_TYPE_CONCAVE)
	{
		if (dir == CConst::DIR_HIGH)
		{
			try
			{
				x = m_upper[idx].id;
				y = m_upper[idx].y;
				return true;
			}
			catch (...) {
				return false;
			}

		}
		else if (dir == CConst::DIR_LOW)
		{
			try
			{
				x = m_lower[idx].id;
				y = m_lower[idx].y;
				return true;
			}
			catch (...) {
				return false;
			}
		}
	}
	else if (typ == CConst::BUFFER_TYPE_ZIGZAG)
	{
		if (dir == CConst::DIR_HIGH)
		{
			try
			{
				x = m_zz_h[idx].id;
				y = m_zz_h[idx].y;
				return true;
			}
			catch (...) {
				return false;
			}
		}
		else if (dir == CConst::DIR_LOW)
		{
			try
			{
				x = m_zz_l[idx].id;
				y = m_zz_l[idx].y;
				return true;
			}
			catch (...) {
				return false;
			}
		}
	}
	return false;

}

CConcave::CConcave(const double scale_x, const double arm_size) :
	m_arm_size(minmax(arm_size, 0.0, 100000.0)),
	m_scale_x(minmax(scale_x, 0.000001, 100000)),
	m_scale_factor(1.0 / m_scale_x),
	m_size(std::max(1,int(m_arm_size*m_scale_factor))*2),
	m_prev_calculated(0),
	m_last_h(0, 0.0, 0.0),
	m_last_l(0, 0.0, 0.0),
	m_state_h(0),
	m_state_l(0)


{

}


int CConcave::push(const int x, const double h, const double l, const time_t t0, const time_t t1)
{
	int result = 0;
	try
	{
		result = m_series_h.push(x, h, t0, t1);
		result = m_series_l.push(x, l, t0, t1);
	}
	catch (...)
	{
		result = -9999;
	}

	return result;
}

bool CConcave::calculate()
{
	if (!m_series_h.is_adding()) return false;
	const std::deque<Price> & series_h = m_series_h.get_series();
	size_t sz = series_h.size();
	if (sz < 3)return false;
	for (size_t i = m_prev_calculated;i<sz-1; ++i,++m_prev_calculated)
	{

		if (m_upper.size()>0 && m_last_h.id == 0)
		{
			m_last_h = { series_h[i].x, m_scale_x * (double)series_h[i].x, series_h[i].y };
			continue;
		}
		if (m_upper.size() == 0)
		{
			m_upper.emplace_back(series_h[i].x, m_scale_x * (double)series_h[i].x, series_h[i].y);
			m_last_h = { 0,0.0,0.0 };
			continue;
		}

		concave_hull(m_upper, m_last_h, series_h.cbegin()+i, m_arm_size, CConst::DIR_LEFT);
		const size_t upper_sz{ m_upper.size() };
		if (m_state_h == CConst::ZZ_ON)
		{
			size_t x = find_valley(m_upper);
			if (x == 0 && 
				upper_sz >= 2 && 
				m_last_h.id > 0 &&
				valley(m_upper[upper_sz - 2], m_upper[upper_sz - 1], m_last_h)
			)
			{
				x = upper_sz - 1;
			}
			if (x > 0)
			{
				
				m_upper.erase(m_upper.begin(), m_upper.begin() + x);
				m_zz_h.emplace_back(m_upper[0].id, m_upper[0].x, m_upper[0].y);
				m_state_h = CConst::ZZ_OFF;
			}

		}
		else 
		{
			size_t x = find_peak(m_upper);
			if (x > 0)
			{
				m_upper.erase(m_upper.begin(), m_upper.begin() + x);
				m_zz_h.emplace_back(m_upper[0].id, m_upper[0].x, m_upper[0].y);
				m_state_h = CConst::ZZ_ON;
			}
		}

	}
	return true;
}
void CConcave::concave_hull(PointDeque &hull,  Point &last_point, const Point &new_point, const double arm_size, const int dir)
{
	return concave(hull.back(), last_point, new_point, arm_size, dir);
	if (result == CConst::CONCAVE_BRIDGE)
	{
		m_last_h = new_point;
	}
	else if (result == CConst::CONCAVE_SHIFT)
	{

		m_upper.emplace_back(m_last_h.id, m_last_h.x, m_last_h.y);
		Point prev_point{ m_upper.back() };
		m_last_h = prev_point;

		m_last_h = Point(series[i - j].x, m_scale_x * (double)series[i - j].x, series[i - j].h);
		while (--j >= 0)
		{
			const Point new_point{ series[i - j].x, m_scale_x * (double)series[i - j].x, series[i - j].h };
			int result = concave_hull(m_upper, m_last_h, new_point, m_arm_size, CConst::DIR_LEFT);
			if (result == CConst::CONCAVE_BRIDGE)
			{
				m_last_h = new_point;
			}
		}

	}

}

int CConcave::concave(const Point & a, const Point & b, const Point & c, const double arm_size, const int dir)
{
	if ((a.id == b.id && a.x == b.x) || (b.id == c.id && b.x == c.x))
	{
		return CConst::CONCAVE_SKIP;
	}
	if (GreaterThan(c.x - a.x, arm_size))			return CConst::CONCAVE_SHIFT; // Bを正式採用 Cを候補に

	const bool inside{ get_side(a,c,b) == dir * -1 };
	if (inside)	return CConst::CONCAVE_BRIDGE;	// Bを却下しCを候補に
	else return CConst::CONCAVE_SKIP;	// Cを却下
}

bool CConcave::peak(const Point & a, const Point & b, const Point & c) 
{
	return (GreaterThan(b.y, std::fmax(a.y, c.y)));
}
bool CConcave::valley(const Point & a, const Point & b, const Point & c)
{
	return (LessThan(b.y, std::fmin(a.y, c.y)));
}
size_t CConcave::find_peak(const PointDeque & points)
{
	if (points.size() < 3)return 0;
	size_t res = 0;
	for (size_t i = 2; i < points.size(); ++i)
	{
		if (peak(points[i - 2],points[i - 1], points[i]))
		{
			res = i - 1;
			break;
		}
	}
	return res;
}
size_t CConcave::find_valley(const PointDeque & points)
{
	if (points.size() < 3)return 0;
	size_t res = 0;
	for (size_t i = 2; i < points.size(); ++i)
	{
		if (valley(points[i - 2], points[i - 1], points[i]))
		{
			res = i - 1;
			break;
		}
	}
	return res;
}

int CConcave::get_side(const Point &a, const Point &b, const Point &p)
{
	const double n = p.x * (a.y - b.y) + a.x * (b.y - p.y) + b.x * (p.y - a.y);

	if (n > 0)		return  CConst::DIR_LEFT; 
	else if (n < 0) return  CConst::DIR_RIGHT; 
	else            return  CConst::DIR_NONE; 
}

double CConcave::distance(const Point &a , const Point & b) {
	return sqrt((b.x - a.x) * (b.x - a.x) + (b.y - a.y) * (b.y - a.y));
}



size_t CConcave::minmax(const size_t n, const size_t min, const size_t max)
{
	return std::max(min, std::min(max, n));
}

double CConcave::minmax(const double n, const double min, const double max)
{
	return std::max(min, std::min(max, n));
}


bool CConcave::Equal(double a, double b)				{ return fabs(a - b) <= DBL_EPSILON; }
bool CConcave::Zero(double a)							{ return fabs(a) <= DBL_EPSILON; }
bool CConcave::LessThan(double a, double b)				{ return a < (b - DBL_EPSILON); }
bool CConcave::LessThanOrEqual(double a, double b)		{ return a <= (b + DBL_EPSILON); }
bool CConcave::GreaterThan(double a, double b)			{ return a >(b + DBL_EPSILON); }
bool CConcave::GreaterThanOrEqual(double a, double b)	{ return a >= (b + DBL_EPSILON); }

