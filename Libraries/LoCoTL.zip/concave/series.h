#define _USE_MATH_DEFINES
#include <deque> 
#include <numeric>
#include <algorithm>
#include <iostream>
#include <math.h>

struct Price
{
	size_t x = 0;
	double y = 0.0;
	Price() = default;

	Price(size_t x, double y) :
		x(x),
		y(y)
	{}
};


class CSeries
{

public:

	explicit CSeries(const size_t period);
	int push(const size_t x, const double h, const double l,  const time_t t0, const time_t t1);
	const std::deque<Price>& get_h_series() const;
	const std::deque<Price>& get_l_series() const;
	size_t minmax(const size_t n, const size_t min, const size_t max);
	size_t last_x() const;
	size_t prev_x() const;
	bool is_adding(void) const;
//	void pop_h_series(const size_t to);
//	void pop_l_series(const size_t to);
private:
	size_t m_series_size;
	time_t m_last_t;
	size_t m_last_x;
	size_t m_prev_x;
	bool m_is_adding;
	std::deque<Price> m_h_buf;
	std::deque<Price> m_l_buf;
};

