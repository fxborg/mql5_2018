#include "series.h"

CSeries::CSeries():
	m_last_t(0),
	m_last_x(-1),
	m_prev_x(-1),
	m_is_adding(false)
{}

void CSeries::erase(void)
{
	m_buf.erase(m_buf.begin(), m_buf.end());
}

int CSeries::last_x() const
{
	return m_last_x;
}

int CSeries::prev_x() const
{
	return m_prev_x;
}

bool CSeries::is_adding(void) const
{
	return m_is_adding;
}

size_t CSeries::size(void) const
{
	return m_buf.size();
}

int CSeries::push(const int x, const double y, const time_t t0, const time_t t1)
{
	m_is_adding = false;
	if (m_last_x > x) return -1;

	if (m_last_t != 0)
	{
		if (m_last_x == x && m_last_t != t0) throw std::out_of_range("x");
		else if (m_last_x < x && m_last_t != t1) throw std::out_of_range("x");
	}

	int last_x = m_last_x;
	m_last_x = x;
	m_last_t = t0;

	if (last_x == x)
	{
		auto price = m_buf.rbegin();
		price->y = y;
	}
	else
	{
		m_is_adding = true;
		m_prev_x = last_x;
		m_buf.emplace_back(x, y);

	}
	return x;
}

const std::deque<Price>& CSeries::get_series() const
{
	return m_buf;
}

size_t CSeries::minmax(const size_t n, const size_t min, const size_t max)
{
	return std::max(min, std::min(max, n));
}

void CSeries::shift(const size_t to)
{
	if (m_buf.size()> to)
	{
		m_buf.erase(m_buf.begin() , m_buf.begin() + to);
	}
}