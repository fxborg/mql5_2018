
#include <Windows.h>
#include <tchar.h>
#include <iostream>

#include <fstream>
#include <string>
#include <vector>


typedef int(__stdcall *Fn_ExpClass_Create)( double, double, float, float);
typedef int(__stdcall *Fn_ExpClass_Push)(int, size_t, double, double, time_t, time_t);
typedef bool(__stdcall *Fn_ExpClass_Calc)(int);
typedef void(__stdcall *Fn_ExpClass_Destroy)(int);
typedef int(__stdcall *Fn_ExpClass_GetSize)(int, int);
typedef bool(__stdcall *Fn_ExpClass_GetBuffer)(int, int, size_t, size_t &x, double &y, float & slope,int & vertex);
int main()
{
	HMODULE hDll = ::LoadLibrary(_T("concave.dll"));
	if (hDll == 0)
	{
		int errorCode = GetLastError();
		std::cout << errorCode;
		return 1;
	}
	Fn_ExpClass_Create ExpClass_Create = (Fn_ExpClass_Create)GetProcAddress(hDll, "Create");
	Fn_ExpClass_Destroy ExpClass_Destroy = (Fn_ExpClass_Destroy)GetProcAddress(hDll, "Destroy");
	Fn_ExpClass_Push ExpClass_Push = (Fn_ExpClass_Push)GetProcAddress(hDll, "Push");
	Fn_ExpClass_Calc ExpClass_Calc = (Fn_ExpClass_Calc)GetProcAddress(hDll, "Calculate");
	Fn_ExpClass_GetSize ExpClass_GetSize = (Fn_ExpClass_GetSize)GetProcAddress(hDll, "GetSize");
	Fn_ExpClass_GetBuffer ExpClass_GetBuffer = (Fn_ExpClass_GetBuffer)GetProcAddress(hDll, "GetBuffer");

	int ptr = ExpClass_Create(0.1,1.0, 5.0f,10.0f);
	time_t t0 = 1000;
	time_t t1 = 1000;
	t1 = t0;

	std::string src_path = "C:\\Temp\\data\\USDJPYHL.dat";
	std::ifstream fin(src_path);
	if (fin.bad()) {
		std::cout << "File Open Error:" << src_path << std::endl;
		return 1;
	}
	std::cout << "File Open!:" << src_path << std::endl;
	std::string str;
	int n = 551;
	double high,low;
	std::vector<std::vector<double>>sample;
	while (std::getline(fin, str))
	{
		int res = sscanf_s(str.c_str(), "%lf\t%lf", &high, &low);

		if (res != 2)continue;
		n++;
		t1 = t0++;
		int x = ExpClass_Push(ptr, n, high, low, t0, t1);
		
	

	}
	int sz = ExpClass_GetSize(ptr, 1);
	if (sz > 0)
	{
		for (int i = 0; i < sz; i++) {
			size_t x1;
			double y1;
			int vertex;
			float slope;
			ExpClass_GetBuffer(ptr, 1, i, x1, y1, slope,vertex);
			std::cout << x1 << "," << y1 << "->"<< vertex <<std::endl;
		}
	}

	fin.close();
	//
	//
	ExpClass_Destroy(ptr);

	
	system("pause");
	return 0;
}
