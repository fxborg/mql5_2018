#include "series.h"


CSeries::CSeries(const size_t period) :
	m_series_size(minmax(period, 1, 10000)),
	m_last_t(0),
	m_last_x(0),
	m_prev_x(0),
	m_is_adding(false)
{}


size_t CSeries::last_x() const
{
	return m_last_x;
}

size_t CSeries::prev_x() const
{
	return m_prev_x;
}

bool CSeries::is_adding(void) const
{
	return m_is_adding;
}


int CSeries::push(const size_t x, const double h, const double l, const time_t t0, const time_t t1)
{
	m_is_adding = false;

	if (m_last_x > x) return -1;

	if (m_last_t != 0)
	{
		if (m_last_x == x && m_last_t != t0) throw std::out_of_range("x");
		else if (m_last_x < x && m_last_t != t1) throw std::out_of_range("x");
	}

	size_t last_x = m_last_x;
	m_last_x = x;
	m_last_t = t0;

	if ( last_x == x && x>0 )
	{
		auto h_price = m_h_buf.rbegin();
		auto l_price = m_l_buf.rbegin();
		h_price->y = h;
		l_price->y = l;
	}
	else
	{
		m_is_adding = true;
		m_prev_x = last_x;
		m_h_buf.emplace_back(x, h);
		m_l_buf.emplace_back(x, l);

		if (m_h_buf.size() > m_series_size)
		{
			size_t delsz = m_h_buf.size() - m_series_size;
			m_h_buf.erase(m_h_buf.begin(), m_h_buf.begin() + delsz);
		}
		if (m_l_buf.size() > m_series_size)
		{
			size_t delsz = m_l_buf.size() - m_series_size;
			m_l_buf.erase(m_l_buf.begin(), m_l_buf.begin() + delsz);
		}



	}

	return (m_is_adding) ? 1 : 0;
}

const std::deque<Price>& CSeries::get_h_series() const
{
	return m_h_buf;
}
const std::deque<Price>& CSeries::get_l_series() const
{
	return m_l_buf;
}

size_t CSeries::minmax(const size_t n, const size_t min, const size_t max)
{
	return std::max(min, std::min(max, n));
}

//void CSeries::pop_h_series(const size_t to)
//{
//	if (m_h_buf.size() > to)return;
//	{
//		m_h_buf.erase(m_h_buf.begin(), m_h_buf.begin() + to);
//	}
//}
//void CSeries::pop_l_series(const size_t to)
//{
//	if ( m_l_buf.size() > to)return ;
//	{
//		m_l_buf.erase(m_l_buf.begin() , m_l_buf.begin() + to);
//	}
//}