﻿#include "concave.h"

const int CConst::DIR_LEFT = 1;
const int CConst::DIR_RIGHT = -1;
const int CConst::DIR_NONE = 0;
const int CConst::DIR_HIGH = 1;
const int CConst::DIR_LOW = -1;

const int CConst::CONCAVE_BRIDGE = 0; // |A-B-C  -->  |A-C-?
const int CConst::CONCAVE_SHIFT  = 1; // |A-B-C  --> A|B-C-? 
const int CConst::CONCAVE_SKIP   = 2; // |A-B-C  -->  |A-B-?
const int CConst::CONCAVE_ERROR  = -1;

const size_t CConst::SIZE_T_MAX = -1;
const size_t CConst::MAX_BUFFER_SIZE = 5;
EXPORT CConcave * __stdcall Create(const double scale_x, const double arm_size)
{
	return new CConcave(scale_x, arm_size);
}

EXPORT void __stdcall Destroy(CConcave * instance)
{
	delete instance;
}

EXPORT int __stdcall Push(CConcave * instance, const size_t x, const double h, const double l, const time_t t0, const time_t t1)
{
	return instance->push(x, h, l, t0, t1);
}

EXPORT bool __stdcall GetLast(CConcave* instance, const int dir, const int backs,
										size_t & x1, double & y1, bool & is_ex,
										size_t & x2, double & y2)
{
	return instance->get_last( dir, backs, x1, y1, is_ex, x2, y2);
}

int GetShiftCount(CConcave * instance, const int dir)
{
	return instance->get_shift_count(dir);
}

EXPORT int __stdcall PushTrend(CConcave* instance, const double x, const double y, const int dir)
{
	return instance->push_trend(x, y, dir);
}

EXPORT bool __stdcall GetTrend(CConcave* instance, double &x, double &a, double &b, double &r, const int dir)
{
	return instance->get_trend(x, a, b, r, dir);
}
EXPORT void __stdcall ClearTrend(CConcave* instance, const int dir) 
{
	return instance->clear_trend(dir);
}


CConcave::CConcave(const double scale_x, const double arm_size) :
	m_arm_size(minmax(arm_size, 0.0, 100000.0)),
	m_scale_x(minmax(scale_x, 0.000001, 100000)),
	m_scale_factor(1.0 / m_scale_x),
	m_size(std::max(1,int(m_arm_size*m_scale_factor))*3),
	m_angle_rad(( (180.0f-120.0F) * PI / 180.0f)),
	m_last_h(0, 0.0, 0.0),
	m_last_l(0, 0.0, 0.0),
	m_shift_h(0),
	m_shift_l(0),
	m_series(m_size),
	m_up_trend(1),
	m_dn_trend(-1)
{

}

int CConcave::push(const size_t x, const double h, const double l, const time_t t0, const time_t t1)
{
	int result = 0;
	try
	{
		result = m_series.push(x, h, l, t0, t1);
		concave_hull();

	}
	catch (...)
	{
		result = -9999;
	}

	return result;
}

void CConcave::concave_hull()
{

	if (!m_series.is_adding()) return;

	const std::deque<Price> & series_h = m_series.get_h_series();
	const std::deque<Price> & series_l = m_series.get_l_series();
	size_t h_sz = series_h.size();

	if (h_sz < 3)return;

	size_t i = h_sz - 2;
	m_shift_h = 0;
	m_shift_l = 0;
	// upper
	if (m_upper.size() > 0 && m_last_h.id == 0)
	{
		m_last_h = { series_h[i].x, m_scale_x * (double)series_h[i].x, series_h[i].y };
		m_last_h.slope = angle(m_upper.back(), m_last_h);

	}
	else if (m_upper.size() == 0)
	{
		m_upper.emplace_back(series_h[i].x, m_scale_x * (double)series_h[i].x, series_h[i].y);
		m_last_h = { 0,0.0,0.0};
	}
	else
	{

		m_shift_h = concave_hull(m_upper, m_last_h, series_h, i, m_arm_size, CConst::DIR_LEFT);
		if(m_shift_h>0)
		{
			for (int j = 0; j < m_shift_h; j++) 
			{
				if (m_upper.size() > CConst::MAX_BUFFER_SIZE)m_upper.pop_front();
			}
		}

	}
	// lower
	if (m_lower.size() > 0 && m_last_l.id == 0)
	{
		m_last_l = { series_l[i].x, m_scale_x * (double)series_l[i].x, series_l[i].y };
		m_last_l.slope = angle(m_lower.back(), m_last_l);
	}
	else if (m_lower.size() == 0)
	{
		m_lower.emplace_back(series_l[i].x, m_scale_x * (double)series_l[i].x, series_l[i].y);
		m_last_l = { 0,0.0,0.0 };
	}
	else
	{
		m_shift_l=concave_hull(m_lower, m_last_l, series_l, i, m_arm_size, CConst::DIR_RIGHT);
		if(m_shift_l>0)
		{
			for (int j = 0; j < m_shift_l; j++) {
				if (m_lower.size() > CConst::MAX_BUFFER_SIZE)m_lower.pop_front();
			}
		}
	}

	
}


int CConcave::concave_hull(PointDeque & hull, Point & last_point, const std::deque<Price> & series, const size_t idx, const double arm_size, const int dir)
{
	int shift_cnt = 0;
	size_t i = idx;





	while (true)
	{
		Point new_point{ series[i].x, m_scale_x * (double)series[i].x, series[i].y };

		int result = concave(hull.back(), last_point, new_point, arm_size, dir);

		if (result == CConst::CONCAVE_BRIDGE)
		{
			
			last_point = new_point;
			last_point.slope = angle(hull.back(), new_point);

		}
					
		else if (result == CConst::CONCAVE_SHIFT)
		{
			shift_cnt++;
			hull.emplace_back(last_point.id, last_point.x, last_point.y, last_point.slope);
			Point prev_point{ hull.back() };
			if(dir==1) std::cout << prev_point.x << "," << prev_point.y << "," << prev_point.slope << std::endl;

			size_t k = i;
			while (--k >= 0 && series[k].x > prev_point.id)
			{
				i = k;
			}
			last_point={ series[i].x, m_scale_x * (double)series[i].x, series[i].y };
			last_point.slope = angle(hull.back(), last_point);

		}


		if (idx <= i) break;
		i++; 
	}
	return shift_cnt;
}

int CConcave::concave(const Point & a, const Point & b, const Point & c, const double arm_size, const int dir)
{
	if ((a.id == b.id && a.x == b.x) || (b.id == c.id && b.x == c.x))
	{
		return CConst::CONCAVE_SKIP;
	}
	
	if (c.x - a.x > arm_size) return CConst::CONCAVE_SHIFT; // Bを正式採用 Cを候補に
	
	const bool inside{ get_side(a,c,b) == dir * -1 };
	if (inside)
	{
		return CConst::CONCAVE_BRIDGE;	// Bを却下しCを候補に
	}
	else
	{
		if(check_distance(a, b, c, arm_size, dir)) return CConst::CONCAVE_SHIFT; // Bを正式採用 Cを候補に
		return CConst::CONCAVE_SKIP;	// Cを却下

	}

}
bool CConcave::check_distance(const Point & a, const Point & b, const Point & c, const double arm_size, const int dir)
{
//	if (c.x - a.x >= arm_size * 0.25)
	{
		const float angle{ b.slope - a.slope };
		const float slope{ -dir*(b.slope - a.slope) };

		//if (slope > 0.0f)
		{			
			const double alpha{ (b.y - a.y) / (b.x - a.x) };
			const double beta{ b.y - alpha*b.x };
			const double y{ alpha*c.x + beta };
			const double acos{cos(double(slope)) };
			return acos*arm_size <= distance(a, { 0, c.x, y });
		}
	}
	return false;
}

int CConcave::get_shift_count(const int dir) const
{
	if (dir == CConst::DIR_HIGH) return m_shift_h;
	else if (dir == CConst::DIR_LOW) return m_shift_l;
	else return 0;
}
bool CConcave::get_last(const int dir, const int backs, size_t & x1, double & y1, bool & is_ex,  size_t & x2, double & y2) const
{
	if (dir == CConst::DIR_HIGH)
	{
		const int last{ int(m_upper.size())-1 };
		if (last-backs < 0)	return false;
		if (backs == 0)
		{
			x1		= m_upper[last].id;
			y1		= m_upper[last].y;
			is_ex = (m_upper[last].slope > -0.0174533f && m_last_h.slope < 0.0f);
			x2		= m_last_h.id;
			y2		= m_last_h.y;
			return true;
		}
		else if(backs > 0)
		{
			x1		= m_upper[last - backs].id;
			y1		= m_upper[last - backs].y;
			is_ex = (m_upper[last - backs].slope > -0.0174533f && m_upper[last - (backs - 1)].slope< 0.0f);

			x2		= m_upper[last - (backs-1)].id;
			y2		= m_upper[last - (backs-1)].y;
			return true;
		}
	}
	else if (dir == CConst::DIR_LOW)
	{
		const int last{ int(m_lower.size()) - 1 };
		if (last - backs < 0)	return false;
		if (backs == 0)
		{
			x1		= m_lower[last].id;
			y1		= m_lower[last].y;
			is_ex =  (m_lower[last].slope  < 0.0174533f &&  m_last_l.slope>0.0f);
			 

			x2		= m_last_l.id;
			y2		= m_last_l.y;
			
			return true;
		}
		else if (backs > 0)
		{
			x1		= m_lower[last-backs].id;
			y1		= m_lower[last-backs].y;
			is_ex = (m_lower[last- backs].slope <0.0174533f &&   m_lower[last - (backs - 1)].slope>0.0f);

			x2		= m_lower[last-(backs-1)].id;
			y2		= m_lower[last-(backs-1)].y;

			return true;
		}
	}
	return false;
}

int CConcave::push_trend(const double x, const double y, const int dir)
{
	if(dir==1)
	{
		m_up_trend.push(x, y);
		return int(m_up_trend.size());
	}
	if(dir==-1)
	{
		m_dn_trend.push(x, y);
		return int(m_dn_trend.size());
	}
	return 0;
}

void CConcave::clear_trend(const int dir)
{
	if (dir == 1)
	{
		m_up_trend.clear();
	}
	if (dir == -1)
	{
		m_dn_trend.clear();
	}

}

bool CConcave::get_trend(double &x, double & a, double & b, double & r, const int dir)
{
	if (dir == 1)
	{
		return m_up_trend.get_trend(x, a, b, r);
	}
	if (dir == -1)
	{
		return m_dn_trend.get_trend(x, a, b, r);
	}
	return false;
}

int CConcave::get_side(const Point &a, const Point &b, const Point &p)
{
	const double n = p.x * (a.y - b.y) + a.x * (b.y - p.y) + b.x * (p.y - a.y);

	if (n > 0)		return  CConst::DIR_LEFT; 
	else if (n < 0) return  CConst::DIR_RIGHT; 
	else            return  CConst::DIR_NONE; 
}

double CConcave::distance(const Point &a , const Point & b) {
	return sqrt((b.x - a.x) * (b.x - a.x) + (b.y - a.y) * (b.y - a.y));
}

size_t CConcave::minmax(const size_t n, const size_t min, const size_t max)
{
	return std::max(min, std::min(max, n));
}

double CConcave::minmax(const double n, const double min, const double max)
{
	return std::max(min, std::min(max, n));
}


float CConcave::angle(const Point &a, const Point &b)
{
	return tbl_atan2(float(b.y - a.y), float(b.x - a.x));
}