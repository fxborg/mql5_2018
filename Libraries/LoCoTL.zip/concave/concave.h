﻿#define EXPORT  extern "C" // __declspec(dllexport)  
#define _USE_MATH_DEFINES

#define DEBUG

#include <deque> 
#include <vector> 
#include <numeric>
#include <algorithm>
#include <iterator>
#include <math.h>
#include <chrono>
#include "series.h"
#include "trend.h"


struct CConst
{
	static const int DIR_LEFT;
	static const int DIR_RIGHT;
	static const int DIR_NONE;
	static const int DIR_HIGH;
	static const int DIR_LOW;
	static const int CONCAVE_BRIDGE;
	static const int CONCAVE_SHIFT;
	static const int CONCAVE_SKIP;
	static const int CONCAVE_ERROR;
	static const size_t SIZE_T_MAX;
	static const size_t MAX_BUFFER_SIZE;

};


struct Point
{
	double x = 0.0;
	double y = 0.0;

	size_t id = 0;

	Point() = default;

	Point(const size_t id, const double x, const double y) :
		 id(id),
		 x(x),
		 y(y)

	{}
};

using PointDeque = std::deque<Point>;



class CConcave
{
public:
	// コンストラクタ
	explicit CConcave(const double scale_x, const double arm_size);
	int push(const size_t x, const double h, const double l, const time_t t0, const time_t t1);
	bool get_last(const int dir, bool & state, size_t & x1, double & y1, size_t & x2, double & y2);

	int push_trend(const double x, const double y, const int dir);
	void clear_trend(const int dir);
	bool get_trend(double &x, double &a, double &b, double &r, const int dir);


private:
	size_t minmax(const size_t n, const size_t min, const size_t max);
	double minmax(const double n, const double min, const double max);
	void concave_hull();
	bool concave_hull(PointDeque &hull, Point &last_point, const std::deque<Price> & series, const size_t i, const double arm_size, const int dir);

	static int concave(const Point & a, const Point & b, const Point & c, const double arm_size, const int dir);

	static int get_side(const Point &a, const Point &b, const Point &p);
	static double distance(const Point &a, const Point &b);

	//--- property
	const double m_arm_size;
	const double m_scale_x;
	const double m_scale_factor;
	const size_t m_size;
	size_t m_prev_calculated;

	Point m_last_h;
	Point m_last_l;

	int m_state_h;
	int m_state_l;

	CSeries m_series;
	
	PointDeque m_upper;
	PointDeque m_lower;

	PointDeque m_zz_h;
	PointDeque m_zz_l;
	
	CTrend m_up_trend;
	CTrend m_dn_trend;


};

//--- インスタンスを生成
EXPORT CConcave * __stdcall Create(const double scale_x, const double arm_size);
//--- インスタンスを破棄
EXPORT void __stdcall Destroy(CConcave* instance);
//--- インスタンス経由でpushメソッドをコール
EXPORT int __stdcall Push(CConcave* instance, const size_t x, const double h, const double l, const time_t t0, const time_t t1);

//--- 結果を取得
EXPORT bool __stdcall GetLast(CConcave* instance, const int dir, bool & state, size_t & x1, double & y1, size_t & x2, double & y2);


EXPORT int  __stdcall PushTrend(CConcave* instance, const double x, const double y, const int dir);
EXPORT void __stdcall ClearTrend(CConcave* instance, const int dir);

EXPORT bool __stdcall GetTrend(CConcave* instance,double &x, double &a, double &b, double &r, const int dir);
