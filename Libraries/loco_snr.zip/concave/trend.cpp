#include "trend.h"


CTrend::CTrend(const int dir) :
	m_dir(direction(dir)),
	m_last_x(-1.0)
{}

void CTrend::push(const double x, const double y)
{
	if (m_last_x >= x)return;
	m_last_x = x;
	m_series.emplace_back(x, y);
	calculate();
}

void CTrend::clear()
{
	m_last_x = -1.0;
	m_series.clear();
	m_hull.clear();
	m_series.shrink_to_fit();
	m_hull.shrink_to_fit();
}

size_t CTrend::size() const
{
	return m_series.size();
}


void CTrend::calculate()
{
	const std::pair<double, double>new_point{ m_series.back() };
	const size_t sz{ m_series.size() };
	convex(m_dir);
	
	for (auto tl_it = begin(m_hull); tl_it != end(m_hull); ++tl_it)
	{
		if (tl_it->flg == 0) continue;

		if (tl_it->flg == -1)
		{
			for (auto it = begin(m_series); it != end(m_series);++it)
			{
				tl_it->residual += abs(it->second - (it->first*tl_it->alpha + tl_it->beta));
			}
			tl_it->flg = 1;
		}
		else
		{
			tl_it->residual += abs(new_point.second - (new_point.first*tl_it->alpha + tl_it->beta));
		}

	}

}

void CTrend::calculate2()
{
	const std::pair<double, double>new_point{ m_series.back() };
	const size_t sz{ m_series.size() };
	convex(m_dir);

	for (int i = 0; i<m_hull.size(); i++)
		{
		if (m_hull[i].flg == 0) continue;

//		std::cout << "!! Trend No:" << int(m_hull[i].x) << std::endl;
		double r = 0.0;
		for(int j=0;j<m_series.size(); j++)
		{
			const double y{ m_series[j].first*m_hull[i].alpha + m_hull[i].beta };
//			std::cout << j << "," << y << std::endl;
			r += abs(m_series[j].second - y);
		}
		m_hull[i].residual = r;
//		std::cout <<"r -->" << r << std::endl;
//		std::cout << std::endl;
		m_hull[i].flg = 1;
	}

}



bool CTrend::get_trend(double &x, double & a,double & b, double &r ) const{
	
	if (m_hull.size() < 2 || m_series.size()<3 ) return false;
	int best_i = 1;

	double res = m_hull[1].residual;
	for (int i = 2; i < m_hull.size(); i++)
	{

		if (m_hull[i].residual < res)
		{
			best_i = i;
			res = m_hull[i].residual;
		}
	}
	x = m_series[0].first;
	a = m_hull[best_i].alpha;
	b = m_hull[best_i].beta;
	r = m_hull[best_i].residual;
	return true;
}


int CTrend::direction(int dir)
{
	return dir > 0 ? 1 : -1;
}

void CTrend::convex(const int dir)
{
	const size_t sz = { m_series.size() };
	const size_t hull_sz{ m_hull.size() };
	if (sz == 0) return;
	TrendPoint new_point{ m_series.back().first,m_series.back().second };
	
	if (sz == 1)
	{
		m_hull.emplace_back(new_point.x, new_point.y);
		m_hull[0].flg = 0; // �v�Z���Ȃ�
		return;
	}

	if (sz == 2)
	{
		double a = (new_point.y - m_hull.back().y) / (new_point.x - m_hull.back().x);
		double b = new_point.y - a * new_point.x;   //b=y-ax
		m_hull.emplace_back(new_point.x, new_point.y, a, b);
		return;
	}

	size_t k = hull_sz;
	// 
	while (k >= 2 && closs(m_hull[k - 2], m_hull[k - 1], new_point) ==  dir)
	{
		m_hull.pop_back();
		k--;
	}

	double a = (new_point.y - m_hull.back().y) / (new_point.x - m_hull.back().x);
	double b = new_point.y - a * new_point.x;   //b=y-ax
	m_hull.emplace_back(new_point.x, new_point.y, a, b);

}
/***
 *
 * -1 to peak
 *  1 to valley
 */
int CTrend::closs(const TrendPoint &o, const TrendPoint &a, const TrendPoint &b)
{
	const double ans{ (a.x - o.x) * (b.y - o.y) - (a.y - o.y) * (b.x - o.x) };
	if (ans > 0.0)  return 1;
	else if(ans < 0.0) return -1;
	else return 0;
}

