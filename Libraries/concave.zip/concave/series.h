#define _USE_MATH_DEFINES
#include <deque> 
#include <numeric>
#include <algorithm>
#include <iostream>
#include <math.h>


struct Price
{
	size_t x = 0;
	double y = 0.0;
	Price() = default;

	Price(size_t x, double y) :
		x(x),
		y(y)
	{}
};


class CSeries
{
public:
	explicit CSeries();
	int push(const int x, const double y,  const time_t t0, const time_t t1);
	const std::deque<Price>& get_series() const;
	size_t minmax(const size_t n, const size_t min, const size_t max);
	void erase(void);
	int last_x() const;
	int prev_x() const;
	bool is_adding(void) const;
	size_t size(void) const;
	void shift(const size_t to);
private:
	time_t m_last_t;
	int m_last_x;
	int m_prev_x;
	std::deque<Price> m_buf;
	bool m_is_adding;
};

